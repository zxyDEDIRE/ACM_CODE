${{g_n={\sum_{i=0}^n{\tbinom{n}{i}}f_i}} \Leftrightarrow {{f_n}={\sum_{i=0}^n (-1)^{n-i}{ \tbinom{n}{i}}g_i}}}$


$g_{n}=\sum_{i=0}^{n}{ \tbinom{n}{i}  f_{i} } \Leftrightarrow $

$ \Leftrightarrow$

${g_{n}={\sum_{i=0}^n}{C_n^i}{f_{i}}{\Leftrightarrow}{\sum_{i=0}^n(-1)^{n-i}{C_n^i}g_i}}$